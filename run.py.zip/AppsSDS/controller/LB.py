'''
Created on Jan 4, 2019

@author: binakarir
'''


class Lb(object):
    '''
    classdocs
    '''

    def __init__(self, *args):
#         self.lb = args
#         self.lb[0]
#         print (self.lb[0])
        pass
        
        '''
        Constructor
        '''


if __name__ == "__main__":
    tes = Lb()
        
