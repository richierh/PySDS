import random

from random import randint
a = randint(1000, 1999)  # randint is inclusive at both ends
print (a)
