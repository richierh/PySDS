'''
Created on Feb 5, 2019

@author: binakarir
'''
class sample():
    c = 3
    def __init__(self):
        self.c = 5
        
r = sample()
print (r.c)        
print (sample.c)