from AppsSDS.controller.csvkonfig import CSV
from AppsSDS.controller.hitung_addlistbox import NewClass,NewClass2,NewClass3
from AppsSDS.controller.grafik_sds import Grafik1
from AppsSDS.controller.hitung_riasec import Riasec