a =20
b = 20
del a

if a :
    print ("okay")

elif b :
    print ("not okay")